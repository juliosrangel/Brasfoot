package br.gov.sp.fatec.brasfut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrasfutApplicationTests {

	@Test
	void contextLoads() {
	}

}
