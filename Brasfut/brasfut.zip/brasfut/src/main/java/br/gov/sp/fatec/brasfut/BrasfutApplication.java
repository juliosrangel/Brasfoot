package br.gov.sp.fatec.brasfut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrasfutApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrasfutApplication.class, args);
	}

}
